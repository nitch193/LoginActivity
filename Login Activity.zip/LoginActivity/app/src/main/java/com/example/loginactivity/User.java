package com.example.loginactivity;

public class User {
    public String name, email, phone;

    public User(){

    }

    public User(String name, String email) {
        this.name = name;
        this.email = email;
        this.phone = phone;
    }
}


